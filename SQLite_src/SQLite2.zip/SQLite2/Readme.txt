Connecting to a SQLite database from Lazarus/Free Pascal applications:

  - SQLite2: This sample application uses the TODBCConnection object (available with Lazarus) to connect to SQLite.

For a detailed description concerning this project, please visit: https://www.streetinfo.lu/computing/lazarus/project/use_sqlite.html.
