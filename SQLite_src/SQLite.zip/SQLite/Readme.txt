Connecting to a SQLite database from Lazarus/Free Pascal applications:

  - SQLite: This sample application uses the TSQLite3Connection object (available with Lazarus) to connect to SQLite; the required
            client library (sqlite3.dll) is part of the SQLite installation files and has to be copied to the project output directory.

For a detailed description concerning this project, please visit: https://www.streetinfo.lu/computing/lazarus/project/use_sqlite.html.
